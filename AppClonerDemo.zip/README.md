# App Cloner Demo

This is a basic Android app for educational purposes that allows a user to select an APK and input a new package name and app name. Actual cloning logic is to be implemented with tools like apktool, jarsigner, etc.

## Features
- Select APK from storage
- Enter new package name and app name
- Placeholder for cloning logic
