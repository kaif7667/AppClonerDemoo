package com.example.appclonerdemo

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var selectApkButton: Button
    private lateinit var cloneButton: Button
    private lateinit var apkNameText: TextView
    private lateinit var packageNameInput: EditText
    private lateinit var appNameInput: EditText

    private var selectedApkUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        selectApkButton = findViewById(R.id.selectApkButton)
        cloneButton = findViewById(R.id.cloneButton)
        apkNameText = findViewById(R.id.apkNameText)
        packageNameInput = findViewById(R.id.packageNameInput)
        appNameInput = findViewById(R.id.appNameInput)

        selectApkButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "application/vnd.android.package-archive"
            startActivityForResult(intent, 100)
        }

        cloneButton.setOnClickListener {
            val apkUri = selectedApkUri
            if (apkUri != null) {
                val newPackage = packageNameInput.text.toString()
                val newAppName = appNameInput.text.toString()
                Toast.makeText(this, "Clone started...\nPackage: $newPackage\nApp: $newAppName", Toast.LENGTH_SHORT).show()
                // TODO: Add actual cloning logic using apktool or shell script
            } else {
                Toast.makeText(this, "Please select an APK first", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                selectedApkUri = uri
                apkNameText.text = getFileName(uri)
            }
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "unknown.apk"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst()) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }
}
